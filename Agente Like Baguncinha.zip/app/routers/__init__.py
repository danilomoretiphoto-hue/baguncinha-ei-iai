"""Routers HTTP da API."""
